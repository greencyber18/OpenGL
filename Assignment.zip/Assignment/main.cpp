#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h

void display1() {
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);



glBegin(GL_QUADS);
glColor3ub(171, 43, 43);
glVertex2f(-0.9, 0.9);
glVertex2f(0.9, 0.9);
glVertex2f(0.9, 0.6);
glVertex2f(-0.9, 0.6);
glEnd();

glBegin(GL_QUADS);
glColor3ub(230, 113, 11);

glVertex2f(0.9, 0.6);
glVertex2f(-0.9, 0.6);
glVertex2f(-0.9, 0.3);
glVertex2f(0.9, 0.3);
glEnd();

glBegin(GL_QUADS);
glColor3ub(255, 230, 0);

glVertex2f(0.9, 0.3);
glVertex2f(-0.9, 0.3);
glVertex2f(-0.9, 0.0);
glVertex2f(0.9, 0.0);
glEnd();

glBegin(GL_QUADS);
glColor3ub(14, 105, 29);

glVertex2f(0.9, 0.0);
glVertex2f(-0.9, 0.0);
glVertex2f(-0.9, -0.3);
glVertex2f(0.9, -0.3);
glEnd();

glBegin(GL_QUADS);
glColor3ub(63, 40, 148);

glVertex2f(0.9, -0.3);
glVertex2f(-0.9, -0.3);
glVertex2f(-0.9, -0.6);
glVertex2f(0.9, -0.6);
glEnd();

glBegin(GL_QUADS);
glColor3ub(102, 10, 97);

glVertex2f(0.9, -0.6);
glVertex2f(-0.9, -0.6);
glVertex2f(-0.9, -0.9);
glVertex2f(0.9, -0.9);
glEnd();

glBegin(GL_QUADS);
glColor3ub(0, 0, 0);

glVertex2f(-0.9, 1.0);
glVertex2f(-1.0, 1.0);
glVertex2f(-1.0, -1.5);
glVertex2f(-0.9, -1.5);
glEnd();

	glFlush();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutCreateWindow("Test");
	glutInitWindowSize(400, 400);
	glutDisplayFunc(display1);
	glutMainLoop();
	return 0;
}


